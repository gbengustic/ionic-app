import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-example',
  templateUrl: './menu-example.page.html',
  styleUrls: ['./menu-example.page.scss'],
})
export class MenuExamplePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
